#set ($component = ${StringUtils.removeAndHump(${NAME}, "-")})
import React from "react"
import styles from "./${NAME}.module.less"

export const $component = () => {
  #[[$END$]]#
  return <div></div>
}